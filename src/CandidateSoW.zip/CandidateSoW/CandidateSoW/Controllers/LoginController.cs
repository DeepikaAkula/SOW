﻿using CandidateSoW.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CandidateSoW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration configuration;
        public LoginController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }
        // GET: api/<LoginController>
        [HttpGet]
        public string LoginGet(string LoginName, string LoginPassword)
        {
            string dbConn = configuration.GetSection("ConnectionStrings").GetSection("DbConnection").Value;
            Db dop = new Db(dbConn);
            try
            {
                string msg = string.Empty;
                LoginModel ln = new LoginModel();
                DataSet ds = dop.loginget(LoginName, LoginPassword);
                if (ds != null)
                {
                    if (ds.Tables[0].Rows[0] != null)
                    {
                        ln.LoginName = ds.Tables[0].Rows[0]["LoginName"].ToString();
                        ln.EmailId = ds.Tables[0].Rows[0]["EmailId"].ToString();
                        ln.RoleName = ds.Tables[0].Rows[0]["RoleName"].ToString();
                        ln.ScreenNames = ds.Tables[0].Rows[0]["ScreenNames"].ToString();
                        ln.Status = ds.Tables[0].Rows[0]["Status"].ToString();
                        ln.PermissionName = ds.Tables[0].Rows[0]["PermissionName"].ToString();
                        return JsonConvert.SerializeObject(ln);
                    }
                    else
                    {
                        msg = "error";
                        return msg;
                    }
                }
                else
                {
                    msg = "error";
                    return msg;
                }
            }
            catch (Exception E)
            {
                return "Entered credentials is invalid! Please check";
            }
        }
        [HttpPut("{LoginName}")]
        public void Put(string LoginName, string LoginPassword, LoginModel lm)
        {
            string dbConn = configuration.GetSection("ConnectionStrings").GetSection("DbConnection").Value;
            Db dop = new Db(dbConn);
            string msg = string.Empty;
            try
            {
                msg = dop.updateLoginTable(LoginName, LoginPassword, lm);
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
        }

    }
}
